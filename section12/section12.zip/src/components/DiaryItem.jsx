import "../css/DiaryItem.css";

// 1. props에 type 추가 & 기본값 설정
const DiaryItem = () => {
  return (
    <h1>DiaryItem</h1>
  );
};

export default DiaryItem;