import { useParams } from "react-router-dom";

const Diary = () => {
  const params = useParams();

  return (
    <div>
      <h1>Diary Page{params.id}번 일기</h1>
    </div>
  );
};

export default Diary;